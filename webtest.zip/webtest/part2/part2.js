// // questao 1

// const divisiveis = []

// for(var passo = 1; passo < 101; passo++) {
//   if(passo % 7 == 0){
//     divisiveis.push(passo)
//   }
// }

// console.log(divisiveis.join(','))


// // questao 2

// function retornaTexto (string , vezes) {
//   var  output = []
//   for(var i = 0; i < vezes; i++) {
//     output.push(string)
//   }
//   return output 
// }

// console.log(retornaTexto("asd", 4))


// // questao 3

// const elemento_pai = document.querySelector(".pai");
// const elemento_filho = document.querySelector(".filho")

// elemento_pai.appendChild(elemento_filho);
// console.log(elemento_filho)



// // questao 4

// const exp = document.querySelectorAll("p")[7]
// exp.innerHTML = "texto alterado"
// console.log(exp)


// const insere = document.querySelectorAll("p")[8]
// if (insere.classList) insere.classList.add("last");
// console.log(insere)



// // questao 5


// function maior(idade){
//   return idade >= 18 ? 'Maior de idade' : 'Menor de idade';
// }
// console.log(maior(10));

// // questao 6
// // 
// var obj = {
//   nomeObj: 'Mouse',
//   pesoObj: '150g'
// }

// function mudarObj(){
//   obj.nomeObj = 'Teclado';
//   obj.pesoObj = '500g';

//   var objArray = [obj.nomeObj, obj.pesoObj];
//   return objArray;
// }

// console.log('resposta 6', mudarObj());

// // questao 7

// const text = 'Eu quero trabalhar na Seri.e Design';
// const palavras = text.split(' ');
// const reverse = palavras.reverse().join('!')
// const ultimaPalavra = palavras[palavras.length - 1]
// const conta = text.length
// const type = typeof(reverse)
// console.log(type)

// // questao 8

// const divs = document.querySelectorAll('#questao-8 div');
// divs.forEach(function(div, i) {
//   div.setAttribute('data-id', i + 1);
// });

// console.log('resposta 8', divs)

// // questao 9

// const content = document.querySelector('.content');
// const subcontainer = document.querySelector('.subcontainer');
// const lis = document.querySelectorAll('.content ul li');
// lis.forEach(function(li) {
//   li.addEventListener('click', function(e){
//     const ulSubcategoria = this.querySelector('.subcontainer ul');
//     ulSubcategoria.style.display = 'block';
//   });
// });
// content.classList.add('active');
// subcontainer.classList.add('active');

// console.log('resposta 9', content, subcontainer, lis);

// // Resposta 10

// function observer() {
//   var target = '';
//   var restSecs = 0;
//   var intervalObserver = setInterval(function() {
//     target = document.querySelector('footer .content');
//     if ($(target).length >= 1 && restSecs <= 5) {
//       //do something
//     } else if (restSecs == 5) {
//       clearInterval(intervalObserver);
//     } else {
//       restSecs++;
//     }
//   }, 1000);
// }
// observer();